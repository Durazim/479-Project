import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HealtheducationPage } from './healtheducation';

@NgModule({
  declarations: [
    HealtheducationPage,
  ],
  imports: [
    IonicPageModule.forChild(HealtheducationPage),
  ],
})
export class HealtheducationPageModule {}
