import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddHealthEducationPage } from './add-health-education';

@NgModule({
  declarations: [
    AddHealthEducationPage,
  ],
  imports: [
    IonicPageModule.forChild(AddHealthEducationPage),
  ],
})
export class AddHealthEducationPageModule {}
